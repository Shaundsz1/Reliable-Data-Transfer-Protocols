#include "../include/simulator.h"
#include <cstring>
#include <iostream>
#include <vector>
#define A_SIDE 0
#define B_SIDE 1
#define RETRANSMISSION_TIMEOUT 15.0

/* ******************************************************************
 ALTERNATING BIT AND GO-BACK-N NETWORK EMULATOR: VERSION 1.1  J.F.Kurose

   This code should be used for PA2, unidirectional data transfer 
   protocols (from A to B). Network properties:
   - one way network delay averages five time units (longer if there
     are other messages in the channel for GBN), but can be larger
   - packets can be corrupted (either the header or the data portion)
     or lost, according to user-defined probabilities
   - packets will be delivered in the order in which they were sent
     (although some can be lost).
**********************************************************************/

/********* STUDENTS WRITE THE NEXT SEVEN ROUTINES *********/

/* called from layer 5, passed the  data to be sent to other side */
struct pkt create_packet(struct msg message, int seq_num);
struct pkt generate_ack(struct pkt received_packet);
int compute_checksum(struct pkt packet);

// Global variables for A-side
int A_next_acknum;  
bool A_is_waiting;  
struct pkt A_recent_packet;
std::vector<struct pkt> A_packet_buffer;
int msg_counter;
int packet_counter;
int B_state;
int buffer_size;

/********* STUDENTS WRITE THE NEXT SEVEN ROUTINES *********/

void A_output(struct msg message) {
  int seq_no = msg_counter % 2;
  pkt new_packet = create_packet(message, seq_no);
  msg_counter++;
  if (A_is_waiting) {
    A_packet_buffer.push_back(new_packet);
    buffer_size++;
  } else {
    A_recent_packet = new_packet;
    tolayer3(A_SIDE, A_recent_packet);
    starttimer(A_SIDE, RETRANSMISSION_TIMEOUT);
    A_next_acknum = A_recent_packet.seqnum;
    A_is_waiting = true;
  }
}

void A_input(struct pkt packet) {
    if (packet.checksum == compute_checksum(packet) && packet.acknum == A_next_acknum) {
        stoptimer(A_SIDE);
        if (buffer_size > 0) {
            A_recent_packet = A_packet_buffer.front();
            tolayer3(A_SIDE, A_recent_packet);
            starttimer(A_SIDE, RETRANSMISSION_TIMEOUT);
            A_packet_buffer.erase(A_packet_buffer.begin());
            buffer_size--;
        }
        A_is_waiting = false;
        std::cout << "ACK " << packet.acknum << " received at A." << std::endl;
    }
}

void A_timerinterrupt() {
    tolayer3(A_SIDE, A_recent_packet);
    starttimer(A_SIDE, RETRANSMISSION_TIMEOUT);
    A_is_waiting = true;
    std::cout << "Retransmission: Packet with seqnum " << A_recent_packet.seqnum << std::endl;
}

void A_init() {
    A_next_acknum = 0;
    A_is_waiting = false;
    msg_counter = 0;
    buffer_size = 0;
}

void B_input(struct pkt packet) {
  int expected_seq = packet_counter % 2;
  if (packet.checksum == compute_checksum(packet) && packet.seqnum == expected_seq) {
      tolayer5(B_SIDE, packet.payload);
      pkt ack_packet;
      ack_packet = generate_ack(packet);
      tolayer3(B_SIDE, ack_packet);
      packet_counter++;
  } else {
      std::cout << "Corrupted packet received at B." << std::endl;
  }
}

int compute_checksum(struct pkt packet) {
    int checksum = packet.seqnum + packet.acknum;
    for (int i = 0; i < 20; i++) {
        checksum += packet.payload[i];
    }
    return checksum;
}

struct pkt generate_ack(struct pkt received_pkt) {
    pkt ack_packet;
    ack_packet.acknum = received_pkt.seqnum;
    ack_packet.checksum = compute_checksum(ack_packet);
    return ack_packet;
}

void B_init() {
    B_state = 0;
}

struct pkt create_packet(struct msg message, int seq_num) {
    pkt new_packet;
    new_packet.seqnum = seq_num;  
    std::memcpy(new_packet.payload, message.data, sizeof(message.data));
    new_packet.checksum = compute_checksum(new_packet);
    return new_packet;
}
