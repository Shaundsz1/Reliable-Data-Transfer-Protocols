#include "../include/simulator.h"
#include <cstring>
#include <iostream>
#include <vector>

#define A 0
#define B 1
#define TIMEOUT 100.0

// Global variables for entity A
int A_base, A_nextseqnum;
std::vector<pkt> A_buffer; // Buffer to store packets
int window_size;

// Global variables for entity B
int current_state_B;
// Function prototypes
int calculate_checksum(struct pkt packet);
struct pkt make_pkt(struct msg message, int seqnum);
struct pkt create_ack_packet(struct pkt packet);
/* ******************************************************************
 ALTERNATING BIT AND GO-BACK-N NETWORK EMULATOR: VERSION 1.1  J.F.Kurose

   This code should be used for PA2, unidirectional data transfer 
   protocols (from A to B). Network properties:
   - one way network delay averages five time units (longer if there
     are other messages in the channel for GBN), but can be larger
   - packets can be corrupted (either the header or the data portion)
     or lost, according to user-defined probabilities
   - packets will be delivered in the order in which they were sent
     (although some can be lost).
**********************************************************************/

/********* STUDENTS WRITE THE NEXT SEVEN ROUTINES *********/

/* called from layer 5, passed the  data to be sent to other side */

// Function to calculate checksum
int calculate_checksum(struct pkt packet) {
    int checksum = packet.seqnum + packet.acknum;
    for (int i = 0; i < 20; i++) {
        checksum += packet.payload[i];
    }
    return checksum;
}

// Function to create a packet
struct pkt make_pkt(struct msg message, int seqnum) {
    pkt packet;
    packet.seqnum = seqnum;
    std::memcpy(packet.payload, message.data, sizeof(message.data));
    packet.checksum = calculate_checksum(packet);
    return packet;
}
// Function to create ACK packet
struct pkt create_ack_packet(struct pkt received_packet) {
    pkt ack_packet;
    ack_packet.acknum = received_packet.seqnum;
    ack_packet.checksum = calculate_checksum(ack_packet);
    return ack_packet;
}

void A_output(struct msg message) {
    if (A_nextseqnum < A_base + window_size) {
        pkt packet = make_pkt(message, A_nextseqnum);
        while (A_buffer.size() <= A_nextseqnum - A_base) {
            A_buffer.push_back(pkt()); // Expand buffer if needed
        }
        A_buffer[A_nextseqnum - A_base] = packet;
        tolayer3(A, packet);
        if (A_base == A_nextseqnum) {
            starttimer(A, TIMEOUT);
        }
        A_nextseqnum++;
    }
}
/* called from layer 3, when a packet arrives for layer 4 */
void A_input(struct pkt packet) {
    if (packet.checksum == calculate_checksum(packet) && packet.acknum >= A_base) {
        A_base = packet.acknum + 1;
        if (A_base == A_nextseqnum) {
            stoptimer(A);
        } else {
            stoptimer(A);
            starttimer(A, TIMEOUT);
        }
    }
}
/* called when A's timer goes off */
void A_timerinterrupt() {
    starttimer(A, TIMEOUT);
    for (int i = 0; i < A_nextseqnum - A_base; i++) {
        tolayer3(A, A_buffer[i]);
    }
}
/* the following routine will be called once (only) before any other */
/* entity A routines are called. You can use it to do any initialization */
void A_init() {
    A_base = A_nextseqnum = 0;
    window_size = getwinsize();
    A_buffer.clear();
}

/* called from layer 3, when a packet arrives for layer 4 at B*/
void B_input(struct pkt packet) {
    if (packet.checksum == calculate_checksum(packet) && packet.seqnum == current_state_B) {
        tolayer5(B, packet.payload);
        pkt ack = create_ack_packet(packet);
        tolayer3(B, ack);
        current_state_B++;
    }
}

/* the following rouytine will be called once (only) before any other */
/* entity B routines are called. You can use it to do any initialization */
void B_init() {
    current_state_B = 0;
}