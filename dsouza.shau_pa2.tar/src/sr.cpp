#include "../include/simulator.h"
#include <cstring>
#include <iostream>
#include <vector>
#include <map>

#define A 0
#define B 1
#define TIMEOUT 100.0
/* ******************************************************************
 ALTERNATING BIT AND GO-BACK-N NETWORK EMULATOR: VERSION 1.1  J.F.Kurose

   This code should be used for PA2, unidirectional data transfer 
   protocols (from A to B). Network properties:
   - one way network delay averages five time units (longer if there
     are other messages in the channel for GBN), but can be larger
   - packets can be corrupted (either the header or the data portion)
     or lost, according to user-defined probabilities
   - packets will be delivered in the order in which they were sent
     (although some can be lost).
**********************************************************************/

/********* STUDENTS WRITE THE NEXT SEVEN ROUTINES *********/

int A_base, A_nextseqnum;
std::vector<pkt> A_buffer; 
int window_size;
std::map<int, float> timer_start_times; 


int B_expectedseqnum;
std::map<int, pkt> B_buffer; 


int calculate_checksum(struct pkt packet);
struct pkt make_pkt(struct msg message, int seqnum);
struct pkt create_ack_packet(int seqnum);
bool is_corrupt(struct pkt packet);

int calculate_checksum(struct pkt packet) {
    int checksum = packet.seqnum + packet.acknum;
    for (int i = 0; i < 20; i++) {
        checksum += packet.payload[i];
    }
    return checksum;
}

struct pkt make_pkt(struct msg message, int seqnum) {
    pkt packet;
    packet.seqnum = seqnum;
    std::memcpy(packet.payload, message.data, sizeof(message.data));
    packet.checksum = calculate_checksum(packet);
    return packet;
}

struct pkt create_ack_packet(int seqnum) {
    pkt ack_packet;
    ack_packet.acknum = seqnum;
    ack_packet.checksum = calculate_checksum(ack_packet);
    return ack_packet;
}

bool is_corrupt(struct pkt packet) {
    return calculate_checksum(packet) != packet.checksum;
}

void A_output(struct msg message) {
    if (A_nextseqnum < A_base + window_size) {
        pkt packet = make_pkt(message, A_nextseqnum);
        A_buffer[A_nextseqnum % window_size] = packet;
        tolayer3(A, packet);
        if (timer_start_times.find(A_base) == timer_start_times.end()) {
            timer_start_times[A_base] = get_sim_time();
            starttimer(A, TIMEOUT);
        }
        A_nextseqnum++;
    }
}
/* called from layer 3, when a packet arrives for layer 4 */
void A_input(struct pkt packet) {
    if (!is_corrupt(packet) && packet.acknum >= A_base && packet.acknum < A_nextseqnum) {
        int new_base = packet.acknum + 1;
        while (A_base < new_base) {
            timer_start_times.erase(A_base);
            A_base++;
        }
        if (A_base == A_nextseqnum) {
            stoptimer(A);
        } else {
            float next_timer_start = timer_start_times[A_base];
            float elapsed_time = get_sim_time() - next_timer_start;
            stoptimer(A);
            starttimer(A, std::max(TIMEOUT - elapsed_time, 0.0));
        }
    }
}
/* called when A's timer goes off */
void A_timerinterrupt() {
    starttimer(A, TIMEOUT);
    float current_time = get_sim_time();
    for (int i = A_base; i < A_nextseqnum; i++) {
        if (timer_start_times.find(i) == timer_start_times.end() || current_time - timer_start_times[i] >= TIMEOUT) {
            tolayer3(A, A_buffer[i % window_size]);
            timer_start_times[i] = current_time;
        }
    }
}
/* the following routine will be called once (only) before any other */
/* entity A routines are called. You can use it to do any initialization */
void A_init() {
    A_base = A_nextseqnum = 0;
    window_size = getwinsize();
    A_buffer.resize(window_size);
    timer_start_times.clear();
}
/* called from layer 3, when a packet arrives for layer 4 at B*/
void B_input(struct pkt packet) {
    if (!is_corrupt(packet) && packet.seqnum >= B_expectedseqnum && packet.seqnum < B_expectedseqnum + window_size) {
        if (packet.seqnum == B_expectedseqnum) {
            tolayer5(B, packet.payload);
            pkt ack_packet = create_ack_packet(packet.seqnum);
            tolayer3(B, ack_packet);
            B_expectedseqnum++;
            while (B_buffer.find(B_expectedseqnum) != B_buffer.end()) {
                tolayer5(B, B_buffer[B_expectedseqnum].payload);
                B_buffer.erase(B_expectedseqnum);
                pkt ack_packet = create_ack_packet(B_expectedseqnum);
                tolayer3(B, ack_packet);
                B_expectedseqnum++;
            }
        } else if (packet.seqnum > B_expectedseqnum) {
            B_buffer[packet.seqnum] = packet;
            pkt ack_packet = create_ack_packet(packet.seqnum);
            tolayer3(B, ack_packet);
        }
    }
}
/* the following rouytine will be called once (only) before any other */
/* entity B routines are called. You can use it to do any initialization */
void B_init() {
    B_expectedseqnum = 0;
    B_buffer.clear();
}